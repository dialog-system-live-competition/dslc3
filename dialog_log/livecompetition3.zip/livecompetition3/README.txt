=======================================================================================
Distribution of preliminary evaluation data for Live Competition 2020

If you have any question
Please contact: dialog-system-live-competition-ml@googlegroups.com

Organizers:
Ryuichiro Higashinaka (Nagoya University)
Kotaro Funakoshi (Tokyo Institute of Technology)
Michimasa Inaba (University of Electro-Communications)
Yuiko Tsunomori (NTT Docomo)
Tetsuro Takahashi (Fujitsu Laboratories, LTD)
Reina Akama (Tohoku University)
Mayumi Usami (National Institute for Japanese LAnguage and Linguistics)
Yoshiko Kawabata (National Institute for Japanese LAnguage and Linguistics)
Masahiro Mizukami (NTT)
Masato Komuro (Chiba University)
Dolça Tellols Asensi (Tokyo Institute of Technology))

=======================================================================================
Live competition 3 had two types of challenge, open track and
situation track. The data contain dialogue history made with 5
systems for open track, and 6 systems for situation track. There are
dialogue history made with 11 systems in total.

This data were made by crowdsourcing. A worker can have one dialogue
with a system.  The number of dialogue is diverse (38 -- 53) due to
elimination of insufficient dialogues.  All dialogue histories begin
with system utterance. You can find "speaker" attribute in each
turn. "S" indicates system utterance, and "U" indicates user
utterance.

All dialogue histories have 30 turns except situation/FCL.
Dialogue histories of FCL has 14 system utterances and 15 user
utterances, and the others have 15 system utterances and 15 user
utterances.

=======================================================================================
Version 1.0 (Sep. 5 2021)

